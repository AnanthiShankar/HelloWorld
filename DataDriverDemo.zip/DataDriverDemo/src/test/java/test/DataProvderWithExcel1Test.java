package test;

import org.testng.annotations.Test;

public class DataProvderWithExcel1Test {

  @Test
  public void afterMethodTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void beforeMethodTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void dpTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void fTest() {
    throw new RuntimeException("Test not implemented");
  }
}
